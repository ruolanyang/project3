// Generated from /Users/yiling/Desktop/2024 winter/232B/Project1/src/main/java/grammar/XqueyGrammar.g4 by ANTLR 4.13.1
package grammar;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link XqueyGrammarParser}.
 */
public interface XqueyGrammarListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by the {@code RpXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterRpXq(XqueyGrammarParser.RpXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RpXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitRpXq(XqueyGrammarParser.RpXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StringXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterStringXq(XqueyGrammarParser.StringXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StringXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitStringXq(XqueyGrammarParser.StringXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ParaXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterParaXq(XqueyGrammarParser.ParaXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParaXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitParaXq(XqueyGrammarParser.ParaXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ApXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterApXq(XqueyGrammarParser.ApXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ApXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitApXq(XqueyGrammarParser.ApXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code JoinXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterJoinXq(XqueyGrammarParser.JoinXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code JoinXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitJoinXq(XqueyGrammarParser.JoinXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterBinaryXq(XqueyGrammarParser.BinaryXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitBinaryXq(XqueyGrammarParser.BinaryXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code VarXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterVarXq(XqueyGrammarParser.VarXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code VarXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitVarXq(XqueyGrammarParser.VarXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code LetXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterLetXq(XqueyGrammarParser.LetXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code LetXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitLetXq(XqueyGrammarParser.LetXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ForXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterForXq(XqueyGrammarParser.ForXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ForXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitForXq(XqueyGrammarParser.ForXqContext ctx);
	/**
	 * Enter a parse tree produced by the {@code TagXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void enterTagXq(XqueyGrammarParser.TagXqContext ctx);
	/**
	 * Exit a parse tree produced by the {@code TagXq}
	 * labeled alternative in {@link XqueyGrammarParser#xq}.
	 * @param ctx the parse tree
	 */
	void exitTagXq(XqueyGrammarParser.TagXqContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#constantList}.
	 * @param ctx the parse tree
	 */
	void enterConstantList(XqueyGrammarParser.ConstantListContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#constantList}.
	 * @param ctx the parse tree
	 */
	void exitConstantList(XqueyGrammarParser.ConstantListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code Join1}
	 * labeled alternative in {@link XqueyGrammarParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoin1(XqueyGrammarParser.Join1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code Join1}
	 * labeled alternative in {@link XqueyGrammarParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoin1(XqueyGrammarParser.Join1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code Join2}
	 * labeled alternative in {@link XqueyGrammarParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoin2(XqueyGrammarParser.Join2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code Join2}
	 * labeled alternative in {@link XqueyGrammarParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoin2(XqueyGrammarParser.Join2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code Join3}
	 * labeled alternative in {@link XqueyGrammarParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void enterJoin3(XqueyGrammarParser.Join3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code Join3}
	 * labeled alternative in {@link XqueyGrammarParser#joinClause}.
	 * @param ctx the parse tree
	 */
	void exitJoin3(XqueyGrammarParser.Join3Context ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#forClause}.
	 * @param ctx the parse tree
	 */
	void enterForClause(XqueyGrammarParser.ForClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#forClause}.
	 * @param ctx the parse tree
	 */
	void exitForClause(XqueyGrammarParser.ForClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#letClause}.
	 * @param ctx the parse tree
	 */
	void enterLetClause(XqueyGrammarParser.LetClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#letClause}.
	 * @param ctx the parse tree
	 */
	void exitLetClause(XqueyGrammarParser.LetClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void enterWhereClause(XqueyGrammarParser.WhereClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#whereClause}.
	 * @param ctx the parse tree
	 */
	void exitWhereClause(XqueyGrammarParser.WhereClauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#returnClause}.
	 * @param ctx the parse tree
	 */
	void enterReturnClause(XqueyGrammarParser.ReturnClauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#returnClause}.
	 * @param ctx the parse tree
	 */
	void exitReturnClause(XqueyGrammarParser.ReturnClauseContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EqCond2}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEqCond2(XqueyGrammarParser.EqCond2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code EqCond2}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEqCond2(XqueyGrammarParser.EqCond2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code CompoundCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterCompoundCond(XqueyGrammarParser.CompoundCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CompoundCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitCompoundCond(XqueyGrammarParser.CompoundCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EqCond1}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEqCond1(XqueyGrammarParser.EqCond1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code EqCond1}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEqCond1(XqueyGrammarParser.EqCond1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code SatCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterSatCond(XqueyGrammarParser.SatCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SatCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitSatCond(XqueyGrammarParser.SatCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EmptyCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterEmptyCond(XqueyGrammarParser.EmptyCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EmptyCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitEmptyCond(XqueyGrammarParser.EmptyCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NegCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterNegCond(XqueyGrammarParser.NegCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NegCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitNegCond(XqueyGrammarParser.NegCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ParaCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterParaCond(XqueyGrammarParser.ParaCondContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParaCond}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitParaCond(XqueyGrammarParser.ParaCondContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IsCond1}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterIsCond1(XqueyGrammarParser.IsCond1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code IsCond1}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitIsCond1(XqueyGrammarParser.IsCond1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code IsCond2}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterIsCond2(XqueyGrammarParser.IsCond2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code IsCond2}
	 * labeled alternative in {@link XqueyGrammarParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitIsCond2(XqueyGrammarParser.IsCond2Context ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#satisfy}.
	 * @param ctx the parse tree
	 */
	void enterSatisfy(XqueyGrammarParser.SatisfyContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#satisfy}.
	 * @param ctx the parse tree
	 */
	void exitSatisfy(XqueyGrammarParser.SatisfyContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#startTag}.
	 * @param ctx the parse tree
	 */
	void enterStartTag(XqueyGrammarParser.StartTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#startTag}.
	 * @param ctx the parse tree
	 */
	void exitStartTag(XqueyGrammarParser.StartTagContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#endTag}.
	 * @param ctx the parse tree
	 */
	void enterEndTag(XqueyGrammarParser.EndTagContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#endTag}.
	 * @param ctx the parse tree
	 */
	void exitEndTag(XqueyGrammarParser.EndTagContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#ap}.
	 * @param ctx the parse tree
	 */
	void enterAp(XqueyGrammarParser.ApContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#ap}.
	 * @param ctx the parse tree
	 */
	void exitAp(XqueyGrammarParser.ApContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp3}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp3(XqueyGrammarParser.UnaryRp3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp3}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp3(XqueyGrammarParser.UnaryRp3Context ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryRp1}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryRp1(XqueyGrammarParser.BinaryRp1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryRp1}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryRp1(XqueyGrammarParser.BinaryRp1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp4}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp4(XqueyGrammarParser.UnaryRp4Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp4}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp4(XqueyGrammarParser.UnaryRp4Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ParaRp}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterParaRp(XqueyGrammarParser.ParaRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParaRp}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitParaRp(XqueyGrammarParser.ParaRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryRp2}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterBinaryRp2(XqueyGrammarParser.BinaryRp2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryRp2}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitBinaryRp2(XqueyGrammarParser.BinaryRp2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp1}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp1(XqueyGrammarParser.UnaryRp1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp1}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp1(XqueyGrammarParser.UnaryRp1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp2}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp2(XqueyGrammarParser.UnaryRp2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp2}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp2(XqueyGrammarParser.UnaryRp2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterFilterRp(XqueyGrammarParser.FilterRpContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitFilterRp(XqueyGrammarParser.FilterRpContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp5}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp5(XqueyGrammarParser.UnaryRp5Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp5}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp5(XqueyGrammarParser.UnaryRp5Context ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryRp6}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void enterUnaryRp6(XqueyGrammarParser.UnaryRp6Context ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryRp6}
	 * labeled alternative in {@link XqueyGrammarParser#rp}.
	 * @param ctx the parse tree
	 */
	void exitUnaryRp6(XqueyGrammarParser.UnaryRp6Context ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryFt1}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterBinaryFt1(XqueyGrammarParser.BinaryFt1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryFt1}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitBinaryFt1(XqueyGrammarParser.BinaryFt1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code BinaryFt2}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterBinaryFt2(XqueyGrammarParser.BinaryFt2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code BinaryFt2}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitBinaryFt2(XqueyGrammarParser.BinaryFt2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code ParaFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterParaFt(XqueyGrammarParser.ParaFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParaFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitParaFt(XqueyGrammarParser.ParaFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code NegFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterNegFt(XqueyGrammarParser.NegFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code NegFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitNegFt(XqueyGrammarParser.NegFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CompoundFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterCompoundFt(XqueyGrammarParser.CompoundFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CompoundFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitCompoundFt(XqueyGrammarParser.CompoundFtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void enterUnaryFt(XqueyGrammarParser.UnaryFtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryFt}
	 * labeled alternative in {@link XqueyGrammarParser#filter}.
	 * @param ctx the parse tree
	 */
	void exitUnaryFt(XqueyGrammarParser.UnaryFtContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#pathOp}.
	 * @param ctx the parse tree
	 */
	void enterPathOp(XqueyGrammarParser.PathOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#pathOp}.
	 * @param ctx the parse tree
	 */
	void exitPathOp(XqueyGrammarParser.PathOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#docName}.
	 * @param ctx the parse tree
	 */
	void enterDocName(XqueyGrammarParser.DocNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#docName}.
	 * @param ctx the parse tree
	 */
	void exitDocName(XqueyGrammarParser.DocNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#fileName}.
	 * @param ctx the parse tree
	 */
	void enterFileName(XqueyGrammarParser.FileNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#fileName}.
	 * @param ctx the parse tree
	 */
	void exitFileName(XqueyGrammarParser.FileNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#tagName}.
	 * @param ctx the parse tree
	 */
	void enterTagName(XqueyGrammarParser.TagNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#tagName}.
	 * @param ctx the parse tree
	 */
	void exitTagName(XqueyGrammarParser.TagNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#attName}.
	 * @param ctx the parse tree
	 */
	void enterAttName(XqueyGrammarParser.AttNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#attName}.
	 * @param ctx the parse tree
	 */
	void exitAttName(XqueyGrammarParser.AttNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#compOp}.
	 * @param ctx the parse tree
	 */
	void enterCompOp(XqueyGrammarParser.CompOpContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#compOp}.
	 * @param ctx the parse tree
	 */
	void exitCompOp(XqueyGrammarParser.CompOpContext ctx);
	/**
	 * Enter a parse tree produced by {@link XqueyGrammarParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void enterStringCondition(XqueyGrammarParser.StringConditionContext ctx);
	/**
	 * Exit a parse tree produced by {@link XqueyGrammarParser#stringCondition}.
	 * @param ctx the parse tree
	 */
	void exitStringCondition(XqueyGrammarParser.StringConditionContext ctx);
}