// Generated from /Users/yiling/Desktop/2024 winter/232B/Project1/src/main/java/grammar/XpathGrammar.g4 by ANTLR 4.13.1
package grammar;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link XpathGrammarParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface XpathGrammarVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#ap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAp(XpathGrammarParser.ApContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp3}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp3(XpathGrammarParser.UnaryRp3Context ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryRp1}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryRp1(XpathGrammarParser.BinaryRp1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp4}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp4(XpathGrammarParser.UnaryRp4Context ctx);
	/**
	 * Visit a parse tree produced by the {@code ParaRp}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParaRp(XpathGrammarParser.ParaRpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryRp2}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryRp2(XpathGrammarParser.BinaryRp2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp1}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp1(XpathGrammarParser.UnaryRp1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp2}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp2(XpathGrammarParser.UnaryRp2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code FilterRp}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFilterRp(XpathGrammarParser.FilterRpContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp5}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp5(XpathGrammarParser.UnaryRp5Context ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryRp6}
	 * labeled alternative in {@link XpathGrammarParser#rp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryRp6(XpathGrammarParser.UnaryRp6Context ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryFt1}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryFt1(XpathGrammarParser.BinaryFt1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code BinaryFt2}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryFt2(XpathGrammarParser.BinaryFt2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code ParaFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParaFt(XpathGrammarParser.ParaFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code NegFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegFt(XpathGrammarParser.NegFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CompoundFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompoundFt(XpathGrammarParser.CompoundFtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code UnaryFt}
	 * labeled alternative in {@link XpathGrammarParser#filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryFt(XpathGrammarParser.UnaryFtContext ctx);
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#pathOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPathOp(XpathGrammarParser.PathOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#docName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDocName(XpathGrammarParser.DocNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#fileName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFileName(XpathGrammarParser.FileNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#tagName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTagName(XpathGrammarParser.TagNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#attName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAttName(XpathGrammarParser.AttNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#compOp}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCompOp(XpathGrammarParser.CompOpContext ctx);
	/**
	 * Visit a parse tree produced by {@link XpathGrammarParser#stringCondition}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringCondition(XpathGrammarParser.StringConditionContext ctx);
}