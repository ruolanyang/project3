package xpath;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import express.AbsolutePath;
import express.Grammar;

import grammar.XpathGrammarLexer;
import grammar.XpathGrammarParser;


import org.w3c.dom.Attr;
import org.w3c.dom.Text;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.CharStreams;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

class Resolver implements EntityResolver {

    public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
        if (systemId.contains("play.dtd")) {
            ClassLoader classloader = Thread.currentThread().getContextClassLoader();
            InputStream myDtdRes = classloader.getResourceAsStream("play.dtd");
            return new InputSource(myDtdRes);
        } else {
            return null;
        }
    }
}

public class Xpath {
    public Xpath() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        this.documentBuilder = dbf.newDocumentBuilder();
        this.documentBuilder.setEntityResolver(new Resolver());
    }

    public XpathGrammarParser parse(String path)  {
        final XpathGrammarLexer lexer = new XpathGrammarLexer(CharStreams.fromString(path));
        final CommonTokenStream tokens = new CommonTokenStream(lexer);
        return new XpathGrammarParser(tokens);
    }

    public List<Node> evaluate(String path) throws Exception {
        final ParserRuleContext tree = this.parse(path).ap();
        final GrammarConstruct expBuild = new GrammarConstruct();
        final Grammar rootExp = expBuild.visit(tree);

        AbsolutePath apExp = (AbsolutePath)rootExp;
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        InputStream is = classloader.getResourceAsStream(apExp.getDoc());
        Document doc = documentBuilder.parse(is);

        List<Node> inputNodes = new ArrayList<>();
        inputNodes.add(doc);

        return apExp.evaluate(inputNodes);
    }

    public void transform(List<Node> result) throws Exception{
        TransformerFactory tfFactory = TransformerFactory.newInstance();
        Transformer tf = tfFactory.newTransformer();
        tf.setOutputProperty(OutputKeys.INDENT, "yes");
        for (Node n: result) {
            if(n instanceof Attr) {
                System.out.println(n.getTextContent());
            } else if (n instanceof Text) {
                System.out.println(n.getTextContent());
            } else {
                tf.transform(new DOMSource(n), new StreamResult(
                        new PrintStream(System.out)));
            }
        }
    }

    final private DocumentBuilder documentBuilder;
}



