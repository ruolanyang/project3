package express;

import org.w3c.dom.Node;

import java.util.List;
import java.util.Objects;

public class FilterRp implements Grammar {

    final private Grammar rp;
    final private Grammar ft;

    public FilterRp(Grammar rp, Grammar ft) {
        Objects.requireNonNull(rp, "Relative path is NULL!");
        Objects.requireNonNull(ft, "Filter is NULL!");

        this.rp = rp;
        this.ft = ft;
    }

    @Override
    public List<Node> evaluate(List<Node> inputNodes) throws Exception {
        List<Node> interResult = this.rp.evaluate(inputNodes);
        return this.ft.evaluate(interResult);
    }

    @Override
    public ExpressionKind getExpressionKind() {
        return ExpressionKind.FilterRp;
    }
}
