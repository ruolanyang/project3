package xquery;

import java.io.*;
import java.util.List;
import grammar.XqueyGrammarParser;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import query.Rewrite;
import org.apache.commons.cli.*;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class Main {
    public static void main(String[] args) throws Exception {
        CommandLine commandLine;
        Option option_r = Option.builder("r")
                .hasArg(false)
                .required(false)
                .desc("join rewriter")
                .longOpt("rewrite")
                .build();
        Option option_p = Option.builder("p")
                .hasArg(true)
                .required(true)
                .desc("input query file")
                .longOpt("file path")
                .build();
        Options options = new Options();
        options.addOption(option_r);
        options.addOption(option_p);
        CommandLineParser parser = new DefaultParser();
        commandLine = parser.parse(options, args);
        String filepath = commandLine.getOptionValue("p");  // extra paras would be ignored

        BufferedReader in = new BufferedReader(new FileReader(filepath));
        StringBuilder query = new StringBuilder();
        String str;
        while ((str = in.readLine()) != null) {
            query.append(str.replaceAll("\r\n|\r|\n", " "));
            query.append(" ");
        }
        Xquery xq = new Xquery();

        if (commandLine.hasOption("r")) {
            String rewritten = Rewrite.convert((XqueyGrammarParser.ForXqContext)xq.parse(query.toString()).xq());
            BufferedWriter output = null;
            File file = new File("./rewriteOutput.txt");
            if (!file.exists()) {
                file.createNewFile();
            }
            output = new BufferedWriter(new FileWriter(file));
            output.write(rewritten);
            output.close();
            System.out.print("output rewritten result in rewriteOutput.txt");
        } else {
            try {
                long t1 = System.currentTimeMillis();
                List<Node> result = xq.evaluate(query.toString());
                writeResultToFile(result, "./output1.xml", true);
                long t2 = System.currentTimeMillis();
                System.out.printf("returned results: %d\n", result.size());
                System.out.printf("Query execution time: %d ms\n", t2 - t1);
                xq.transform(result);
            } catch (IOException e) {
                System.err.println("Failed to read file: " + filepath);
                System.err.println(e);
                System.exit(2);
            }
        }
    }
    private static void writeResultToFile(List<Node> rawRes, String fileName, boolean addResEle) {
        try(
                OutputStream resultXMLOStream = new FileOutputStream(fileName)
        ) {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder bd = dbFactory.newDocumentBuilder();
            Document outputDoc = bd.newDocument();
            Element resultEle = outputDoc.createElement("RESULT");
            outputDoc.appendChild(resultEle);
            for(Node old: rawRes){
                try {
                    Node newNode;
                    newNode = outputDoc.importNode(old, true);
                    resultEle.appendChild(newNode);
                } catch (DOMException e) {
                    if (e.code != DOMException.NOT_SUPPORTED_ERR) {
                        throw e;
                    }

                }

            }
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            transformer.transform(new DOMSource(outputDoc),new StreamResult(resultXMLOStream));
        }  catch (IOException e) {
            System.err.println("open result file failed: " + e.getMessage());
        }
        catch (Exception e){
            System.err.println("runtime exception while generating/writing result:" + e.getMessage());
        }
    }
}
