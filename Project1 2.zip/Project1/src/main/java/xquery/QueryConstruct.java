package xquery;

import java.util.*;
import express.Grammar;
import grammar.XqueyGrammarBaseVisitor;
import grammar.XqueyGrammarParser;
import query.*;
import xpath.GrammarConstruct;
import xpath.Xpath;

import org.antlr.v4.runtime.tree.TerminalNode;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
public class QueryConstruct extends XqueyGrammarBaseVisitor<Query>{
    private Map<String, List<Node>> contextMap;
    private final Stack<Map<String, List<Node>>> contextStack;
    private final Xpath xpath;
    private final GrammarConstruct expBuilder;
    private final Document doc;
    public QueryConstruct(Document doc) throws Exception {
        Objects.requireNonNull(doc, "Document is NULL!");
        this.doc = doc;
        this.contextMap = new HashMap<>();
        this.contextStack = new Stack<>();
        this.xpath = new Xpath();
        this.expBuilder = new GrammarConstruct();
    }

    @Override public Query visitJoinXq(XqueyGrammarParser.JoinXqContext ctx) {
        return visitChildren(ctx);
    }

    @Override public Query visitJoin1(XqueyGrammarParser.Join1Context ctx) {
        Query left = visit(ctx.xq(0));
        Query right = visit(ctx.xq(1));
        List<String> leftAtt = new ArrayList<>();
        for (int i = 0; i < ctx.constantList(0).ID().size(); i ++) {
            leftAtt.add(ctx.constantList(0).ID(i).getText());
        }
        List<String> rightAtt = new ArrayList<>();
        for (int i = 0; i < ctx.constantList(1).ID().size(); i ++) {
            rightAtt.add(ctx.constantList(1).ID(i).getText());
        }
        return new Join(left, right, leftAtt, rightAtt);
    }

    @Override public Query visitJoin2(XqueyGrammarParser.Join2Context ctx) {
        Query left = visit(ctx.joinClause());
        Query right = visit(ctx.xq());
        List<String> leftAtt = new ArrayList<>();
        for (int i = 0; i < ctx.constantList(0).ID().size(); i ++) {
            leftAtt.add(ctx.constantList(0).ID(i).getText());
        }
        List<String> rightAtt = new ArrayList<>();
        for (int i = 0; i < ctx.constantList(1).ID().size(); i ++) {
            rightAtt.add(ctx.constantList(1).ID(i).getText());
        }
        return new Join(left, right, leftAtt, rightAtt);
    }

    @Override public Query visitJoin3(XqueyGrammarParser.Join3Context ctx) {
        Query left = visit(ctx.xq());
        Query right = visit(ctx.joinClause());
        List<String> leftAtt = new ArrayList<>();
        for (int i = 0; i < ctx.constantList(0).ID().size(); i ++) {
            leftAtt.add(ctx.constantList(0).ID(i).getText());
        }
        List<String> rightAtt = new ArrayList<>();
        for (int i = 0; i < ctx.constantList(1).ID().size(); i ++) {
            rightAtt.add(ctx.constantList(1).ID(i).getText());
        }
        return new Join(left, right, leftAtt, rightAtt);
    }
    @Override public Query visitRpXq(XqueyGrammarParser.RpXqContext ctx) {
        Query query = visit(ctx.xq());
        Grammar exp = this.expBuilder.visit(xpath.parse(ctx.rp().getText()).rp());
        Query.PathOp op = Query.opFromString(ctx.pathOp().getText());
        return new RpXq(query, op, exp);
    }

    @Override public Query visitStringXq(XqueyGrammarParser.StringXqContext ctx) {
        String stringConst = ctx.STRING().getText();
        return new StringXq(stringConst.substring(1, stringConst.length()-1));
    }
    @Override public Query visitParaXq(XqueyGrammarParser.ParaXqContext ctx) {
        Query query = visit(ctx.xq());
        return new ParaXq(query);
    }

    @Override public Query visitApXq(XqueyGrammarParser.ApXqContext ctx) {
        List<Node> list = null;
        try {
            list = this.xpath.evaluate(ctx.ap().getText());
        } catch (Exception e) {
            list = List.of();
            e.printStackTrace();
        }
        return new ApXq(list);
    }

    @Override public Query visitBinaryXq(XqueyGrammarParser.BinaryXqContext ctx) {
        Query query1 = visit(ctx.xq(0));
        Query query2 = visit(ctx.xq(1));
        return new BinaryXq(query1, query2);
    }

    @Override public Query visitVarXq(XqueyGrammarParser.VarXqContext ctx) {
        return new VarXq(this.contextMap.get(ctx.VAR().getText()));
    }

    @Override public Query visitLetXq(XqueyGrammarParser.LetXqContext ctx) {
        this.constructClause(ctx.letClause().VAR(), ctx.letClause().xq());
        Query query = visit(ctx.xq());
        this.deconstructClause(ctx.letClause().VAR().size());
        return query;
    }

    private void forXq(int count, List<Node> res, XqueyGrammarParser.ForXqContext ctx) throws Exception {
        int size = ctx.forClause().VAR().size();
        if(count == size) {
            // should execute where
            if(null != ctx.letClause()) {
                this.constructClause(ctx.letClause().VAR(), ctx.letClause().xq());
            }
            if(null == ctx.whereClause() || (null != ctx.whereClause() && null != visit(ctx.whereClause().cond()).evaluate(this.doc))) {
                res.addAll(visit(ctx.returnClause().xq()).evaluate(this.doc));
            }
            if(null != ctx.letClause()) {
                this.deconstructClause(ctx.letClause().VAR().size());
            }
        } else {
            String varName = ctx.forClause().VAR(count).getText();
            List<Node> nodeList = visit(ctx.forClause().xq(count)).evaluate(this.doc);
            for(Node node : nodeList) {
                Map<String, List<Node>> oldMap = new HashMap<>(this.contextMap);
                this.contextStack.push(oldMap);
                this.contextMap.put(varName, List.of(node));
                this.forXq(count+1, res, ctx);
                this.contextMap = this.contextStack.pop();
            }
        }
    }

    @Override public Query visitForXq(XqueyGrammarParser.ForXqContext ctx) {
        List<Node> res = new ArrayList<>();
        try {
            this.forXq(0, res, ctx);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new VarXq(res);
    }

    @Override public Query visitTagXq(XqueyGrammarParser.TagXqContext ctx) {
        String tagName = ctx.startTag().tagName().getText();
        Query query = visit(ctx.xq());
        return new TagXq(tagName, query);
    }

    @Override public Query visitForClause(XqueyGrammarParser.ForClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitLetClause(XqueyGrammarParser.LetClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitWhereClause(XqueyGrammarParser.WhereClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitReturnClause(XqueyGrammarParser.ReturnClauseContext ctx) { return visitChildren(ctx); }

    @Override public Query visitEqCond2(XqueyGrammarParser.EqCond2Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new EqCond(q1, q2);
    }

    @Override public Query visitCompoundCond(XqueyGrammarParser.CompoundCondContext ctx) {
        Query c1 = visit(ctx.cond(0));
        Query c2 = visit(ctx.cond(1));
        String conj = ctx.CONJ().getText();
        return new CompoundCond(c1, c2, conj);
    }

    @Override public Query visitEqCond1(XqueyGrammarParser.EqCond1Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new EqCond(q1, q2);
    }

    private void constructClause(List<TerminalNode> varList, List<XqueyGrammarParser.XqContext> queryList) {
        if(null == varList || null == queryList || varList.size() != queryList.size()) {
            throw new IllegalArgumentException();
        }

        int count = varList.size();
        for(int i=0; i<count; i++) {
            try {
                List<Node> valueList = visit(queryList.get(i)).evaluate(this.doc);
                String varName = varList.get(i).getText();
                Map<String, List<Node>> oldMap = new HashMap<>(this.contextMap);
                this.contextMap.put(varName, valueList);
                this.contextStack.push(oldMap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void deconstructClause(int count) {
        if(count < 0 || count > this.contextStack.size()) {
            throw new IllegalArgumentException();
        }
        for(int i=0; i<count; i++) {
            this.contextMap = this.contextStack.pop();
        }
    }

    @Override public Query visitSatCond(XqueyGrammarParser.SatCondContext ctx) {
        this.constructClause(ctx.satisfy().VAR(), ctx.satisfy().xq());

        Query finalCond = visit(ctx.cond());
        Query condQuery = null;
        try {
            condQuery = new SatCond(finalCond.evaluate(this.doc));
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.deconstructClause(ctx.satisfy().VAR().size());
        }

        return condQuery;
    }

    @Override public Query visitEmptyCond(XqueyGrammarParser.EmptyCondContext ctx) {
        Query query = visit(ctx.xq());
        return new EmptyCond(query);
    }

    @Override public Query visitNegCond(XqueyGrammarParser.NegCondContext ctx) {
        return new NegCond(visit(ctx.cond()));
    }

    @Override public Query visitParaCond(XqueyGrammarParser.ParaCondContext ctx) {
        return visit(ctx.cond());
    }

    @Override public Query visitIsCond1(XqueyGrammarParser.IsCond1Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new IsCond(q1, q2);
    }
    @Override public Query visitIsCond2(XqueyGrammarParser.IsCond2Context ctx) {
        Query q1 = visit(ctx.xq(0));
        Query q2 = visit(ctx.xq(1));
        return new IsCond(q1, q2);
    }

    @Override public Query visitStartTag(XqueyGrammarParser.StartTagContext ctx) { return visitChildren(ctx); }
    @Override public Query visitEndTag(XqueyGrammarParser.EndTagContext ctx) { return visitChildren(ctx); }

    @Override public Query visitAp(XqueyGrammarParser.ApContext ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp3(XqueyGrammarParser.UnaryRp3Context ctx) { return visitChildren(ctx); }

    @Override public Query visitBinaryRp1(XqueyGrammarParser.BinaryRp1Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp4(XqueyGrammarParser.UnaryRp4Context ctx) { return visitChildren(ctx); }

    @Override public Query visitParaRp(XqueyGrammarParser.ParaRpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitBinaryRp2(XqueyGrammarParser.BinaryRp2Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp1(XqueyGrammarParser.UnaryRp1Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp2(XqueyGrammarParser.UnaryRp2Context ctx) { return visitChildren(ctx); }

    @Override public Query visitFilterRp(XqueyGrammarParser.FilterRpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp5(XqueyGrammarParser.UnaryRp5Context ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryRp6(XqueyGrammarParser.UnaryRp6Context ctx) { return visitChildren(ctx); }

    @Override public Query visitBinaryFt1(XqueyGrammarParser.BinaryFt1Context ctx) { return visitChildren(ctx); }

    @Override public Query visitBinaryFt2(XqueyGrammarParser.BinaryFt2Context ctx) { return visitChildren(ctx); }

    @Override public Query visitParaFt(XqueyGrammarParser.ParaFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitNegFt(XqueyGrammarParser.NegFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitCompoundFt(XqueyGrammarParser.CompoundFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitUnaryFt(XqueyGrammarParser.UnaryFtContext ctx) { return visitChildren(ctx); }

    @Override public Query visitPathOp(XqueyGrammarParser.PathOpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitDocName(XqueyGrammarParser.DocNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitFileName(XqueyGrammarParser.FileNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitTagName(XqueyGrammarParser.TagNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitAttName(XqueyGrammarParser.AttNameContext ctx) { return visitChildren(ctx); }

    @Override public Query visitCompOp(XqueyGrammarParser.CompOpContext ctx) { return visitChildren(ctx); }

    @Override public Query visitStringCondition(XqueyGrammarParser.StringConditionContext ctx) { return visitChildren(ctx); }
}
