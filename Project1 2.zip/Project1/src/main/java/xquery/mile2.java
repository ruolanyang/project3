package xquery;

import java.io.*;
import java.util.List;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


public class mile2 {
    public static void main(String[] args) throws Exception {
        if(args.length == 0) {
            System.err.println("No query file found!");
            System.exit(1);
        }
        String filepath = args[0];
        try{
            BufferedReader in = new BufferedReader(new FileReader(filepath));
            StringBuilder query = new StringBuilder();
            String str;
            while ((str = in.readLine()) != null) {
                query.append(str.replaceAll("\r\n|\r|\n", " "));
                query.append(" ");
            }
            Xquery xq = new Xquery();
            List<Node> result = xq.evaluate(query.toString());
            writeResultToFile(result, "./output.xml", true);
            System.out.printf("returned results: %d\n", result.size());
            xq.transform(result);


        }catch (IOException e) {
            System.err.println("Failed to read file: " + filepath);
            System.err.println(e);
            System.exit(2);
        }
    }
    private static void writeResultToFile(List<Node> rawRes, String fileName, boolean addResEle) {
        try(
                OutputStream resultXMLOStream = new FileOutputStream(fileName)
        ) {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder bd = dbFactory.newDocumentBuilder();
            Document outputDoc = bd.newDocument();
            //outputDoc.appendChild(resultEle);
            for(Node old: rawRes){
                try {
                    Node newNode;
                    newNode = outputDoc.importNode(old, true);
                    outputDoc.appendChild(newNode);
                    //resultEle.appendChild(newNode);
                } catch (DOMException e) {
                    if (e.code != DOMException.NOT_SUPPORTED_ERR) {
                        throw e;
                    }

                }

            }
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            transformer.transform(new DOMSource(outputDoc),new StreamResult(resultXMLOStream));
        }  catch (IOException e) {
            System.err.println("open result file failed: " + e.getMessage());
        }
        catch (Exception e){
            System.err.println("runtime exception while generating/writing result:" + e.getMessage());
        }
    }
}